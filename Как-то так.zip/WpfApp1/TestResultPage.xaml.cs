﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Newtonsoft.Json;
using static WpfApp1.TestWindow;
using System.Windows.Navigation;

namespace WpfApp1
{
    public partial class TestResultPage : Page
    {
        private List<QuestionAnswer> questionAnswers;

        public TestResultPage()
        {
            InitializeComponent();
            LoadData();
            DisplayQuestions();
        }

        private void LoadData()
        {
            try
            {
                string json = File.ReadAllText("data.json");
                questionAnswers = JsonConvert.DeserializeObject<List<QuestionAnswer>>(json);
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Тест еще не создан.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                btnCheck.IsEnabled = false; // Блокируем кнопку проверки результатов
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки теста: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                questionAnswers = new List<QuestionAnswer>(); // Если возникла ошибка, инициализируем список пустым
            }
        }

        private void DisplayQuestions()
        {
            MainGrid.RowDefinitions.Clear();
            MainGrid.Children.Clear();

            for (int row = 0; row < questionAnswers.Count; row++)
            {
                MainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

         
                TextBlock questionTextBlock = new TextBlock
                {
                    Text = questionAnswers[row].Question,
                    Margin = new Thickness(5),
                    VerticalAlignment = VerticalAlignment.Center,
                    TextWrapping = TextWrapping.Wrap,
                     Foreground = Brushes.White
                };
                Grid.SetRow(questionTextBlock, row);
                Grid.SetColumn(questionTextBlock, 0);
                MainGrid.Children.Add(questionTextBlock);

           
                TextBox answerTextBox = new TextBox
                {
                    Margin = new Thickness(5),
                    VerticalAlignment = VerticalAlignment.Center
                };
                Grid.SetRow(answerTextBox, row);
                Grid.SetColumn(answerTextBox, 1);
                MainGrid.Children.Add(answerTextBox);
            }
        }

        private void btnCheck_Click(object sender, RoutedEventArgs e)
        {
            int correctCount = 0;
            for (int i = 0; i < questionAnswers.Count; i++)
            {
                TextBox answerTextBox = MainGrid.Children.OfType<TextBox>().ElementAt(i);
                if (answerTextBox.Text.Trim() == questionAnswers[i].Answer)
                {
                    correctCount++;
                }
            }

        



            Result resultPage = new Result(correctCount, questionAnswers.Count);
            mainResult.NavigationService.Navigate(resultPage);


        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();

            Window window = Window.GetWindow(this);
            window.Close();
        }
    }
}