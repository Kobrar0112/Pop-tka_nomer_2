﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using Microsoft.Win32;
using System.Windows;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnPassTest_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists("data.json"))
            {
                TestResultPage testResultPage = new TestResultPage();
                this.Content = testResultPage;
            }
            else
            {
                MessageBox.Show("Тест еще не создан.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void btnEditTest_Click(object sender, RoutedEventArgs e)
        {
            EditTestWindow editWindow = new EditTestWindow();
            editWindow.Show();

            this.Close();
           
        }
    }
}