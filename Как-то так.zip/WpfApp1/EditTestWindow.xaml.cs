﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class EditTestWindow : Window
    {
        public EditTestWindow()
        {
            InitializeComponent();
        }



        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            string correctPassword = "123";
            string enteredPassword = textBox.Text;

            if (enteredPassword == correctPassword)
            {
                TestWindow testWindow = new TestWindow();
                mainFrame.NavigationService.Navigate(testWindow);
             
            }
            else
            {
                MessageBox.Show("Пароль неправильный!");
            }
        }

        private void btnReturn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

    }
}
